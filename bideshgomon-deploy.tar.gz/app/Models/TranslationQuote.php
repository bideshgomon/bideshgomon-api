<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TranslationQuote extends Model
{
    //
}
